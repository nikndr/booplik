#include "Sequence.h"

int main()
{
	try {
		Sequence<int> s1(0);
		cout << "add 10 ordinals to empty sequence" << endl;
		for (int i = 0; i < 10; i++) {
			s1.append(i);
		}
		cout << s1 << endl;
		cout << "capacity: " << s1.capacity() << endl;
		cout << "size: " << s1.size() << endl << endl;

		cout << "cutting 5 elements" << endl;
		for (int j = 0; j < 5; j++) {
			s1.cut();
		}
		cout << s1 << endl;
		cout << "capacity: " << s1.capacity() << endl;
		cout << "size: " << s1.size() << endl << endl;

		cout << "adding 4 elements" << endl;
		s1.append(32).append(32).append(1).append(5);
		cout << s1 << endl;
		cout << "capacity: " << s1.capacity() << endl;
		cout << "size: " << s1.size() << endl;
		cout << "full: " << boolalpha << s1.full() << endl << endl;

		cout << "contains 3?: " << boolalpha << s1.contains(3) << endl;
		cout << "contains 10?: " << boolalpha << s1.contains(10) << endl;
		cout << "insert 10 to index 1" << endl;
		s1.insert(10, 1);
		cout << s1 << endl;
		cout << "remove last element" << endl;
		s1.remove(s1.size()-1);
		cout << s1 << endl << endl;
		cout << "get element by index 6" << endl;
		cout << s1[6] << endl;
		cout << s1 << endl;
		cout << "now set it to 0" << endl;
		s1[6] = 0;
		cout << s1 << endl;
		cout << "clear" << endl;
		s1.clear();
		cout << s1 << endl;
		cout << "capacity: " << s1.capacity() << endl;
		cout << "size: " << s1.size() << endl;
		cout << "empty: " << boolalpha << s1.empty() << endl << endl;
	}
	catch (Sequence<int>::BadSeq err) {
		err.trace();
	}
	catch (Array<int>::BadArray err) {
		err.trace();
	}
	return 0;
}